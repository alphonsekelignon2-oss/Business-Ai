package com.businessia.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
 EditText budget, objective, skills, time; TextView result;
 @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
  budget=findViewById(R.id.budget); objective=findViewById(R.id.objective); skills=findViewById(R.id.skills); time=findViewById(R.id.time); result=findViewById(R.id.result);
  findViewById(R.id.generate).setOnClickListener(v->generate());
 }
 void generate(){
  int b=0,o=100000; try{b=Integer.parseInt(budget.getText().toString());}catch(Exception e){} try{o=Integer.parseInt(objective.getText().toString());}catch(Exception e){}
  String s=skills.getText().toString().trim(); String t=time.getText().toString().trim();
  StringBuilder r=new StringBuilder("🔎 IDÉES ADAPTÉES\n\n");
  if(b<=20000){add(r,"1. Création de CV","Créer des CV professionnels avec Canva.","2 000–5 000 FCFA/CV","Faire 3 exemples puis contacter chercheurs d'emploi."); add(r,"2. Affiches pour commerces","Créer des affiches pour boutiques, restaurants et coiffeurs.","2 000–10 000 FCFA/affiche","Contacter 20 commerces avec un exemple."); add(r,"3. Installation WhatsApp Business","Configurer catalogue, messages automatiques et lien WhatsApp.","10 000–30 000 FCFA/client","Proposer le service à 5 petits commerces.");}
  else {add(r,"1. Mini-commerce ciblé","Tester un seul produit demandé avant d'acheter beaucoup de stock.","Marge variable","Tester la demande pendant 7 jours."); add(r,"2. Services digitaux locaux","CV + affiches + aide aux pages sociales.","5 000–30 000 FCFA/service","Créer 3 exemples et démarcher 10 prospects/jour.");}
  add(r,"3. Produit numérique","Créer des fiches, modèles ou petits guides utiles et les vendre en ligne.","2 000–15 000 FCFA/vente","Choisir un problème précis et créer un premier produit simple.");
  r.append("\n📌 Ton objectif : ").append(String.format(Locale.US,"%,d",o)).append(" FCFA/mois\n"); r.append("⏱️ Temps : ").append(t.isEmpty()?"non précisé":t).append("\n"); r.append("🛠️ Compétences : ").append(s.isEmpty()?"débutant":s).append("\n\n⚠️ Ces idées ne garantissent pas un revenu. Teste la demande avant de dépenser beaucoup."); result.setText(r.toString());
 }
 void add(StringBuilder r,String title,String desc,String price,String action){r.append("💼 ").append(title).append("\n").append(desc).append("\n💵 ").append(price).append("\n📅 ").append(action).append("\n\n");}
}
